$(document).ready(function(){

	//GLOBAL VARS
	

	//DISPLAY LIST FUNCTION
	
	
	//EVENT ADD_task FORM SUBMIT 
	
	
	//EVENT REMOVE_task FORM SUBMIT
	
	
});