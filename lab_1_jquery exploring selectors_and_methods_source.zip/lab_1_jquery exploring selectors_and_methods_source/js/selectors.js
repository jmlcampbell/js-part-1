// initialize jQuery command after all page elements load
$(document).ready(function(){

//write at least 5 jquery statements to practice selecting the various elements in the layout and style their CSS.
//See: http://api.jquery.com/category/selectors/
//See: http://api.jquery.com/css/

	
					
});