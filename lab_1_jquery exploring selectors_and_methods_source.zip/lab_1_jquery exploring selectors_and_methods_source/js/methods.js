// initialize jQuery command after all page elements load
	    			
$(document).ready(function(){

//go to: http://api.jquery.com to read about each of the methods below and then set the apropriate button to apply the method to the content below it.

	//hide
	$("#b1").click(function(){
		$("#p1").hide(1000);
	});
		
	//show
	
			
	//toggle
	
		
	//css
	
		
	//css (multiple property changes)
	
		
	//html
	
		
	//prepend
	

	//append

		
	//before
	
		 
	//after
	
		 
	//wrap
	
		 
	//addClass
	
		 
	//clone
	
		 
	//fadeOut
	
		 
	//fadeIn
	
		  
	//fadeToggle
	
		  
	//slideUp
	
		 
	//slideDown
	

	//slideToggle
	
		  
	//animate
	
		 
});