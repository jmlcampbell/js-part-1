Add Twitter user timeline REST API to display in designated sidebar div.
-edit:
js/twitter.js

Bonus: Use Popcorn.js library to add interaction to the video player. Try targeting the #vidnotes div to display wikipedia articles related to the video at given periods of time.

http://popcornjs.org/popcorn-docs/plugins/#Wikipedia