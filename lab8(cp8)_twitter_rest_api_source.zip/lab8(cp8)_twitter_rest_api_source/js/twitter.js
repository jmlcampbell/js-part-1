$(document).ready(function(){

	//start

});

/*

Twitter user Timeline REST API: https://dev.twitter.com/docs/api/1/get/statuses/user_timeline

example URL: https://api.twitter.com/1/statuses/user_timeline.json?callback=?&include_entities=true&include_rts=true&screen_name=cnnbrk&count=10
displays user screen_name = cnnbrk count = 10 most recent tweets.

Bonus: replace http://urls insid ethe tweets with link to that url, and replace @user with link to that twitter user and #term to link searching that term on twitter.

MDN string replacement: https://developer.mozilla.org/en-US/docs/JavaScript/Reference/Global_Objects/String/replace

URL examples:

@cnnbrk becomes <a href="http://twitter.com/cnnbrk" target="_blank">@cnnbrk</a>
#earthquake becomes <a href="http://search.twitter.com/search?q=earthquake" target="_blank">#earthquake</a>

*/