$(document).ready(function(){

	//Create an instance of Popcorn.
	vid1 = Popcorn('#video1');
	
	vid1
		.footnote({
			start: 1,
			end: 13,
			text:"Your watching the New Wrinkle",
			target: "vidnotes"
		})
		.wikipedia({
			start: 25,
			end: 39,
			src: "http://en.wikipedia.org/wiki/Newspaper",
			title: "History of Newspapers",
			target: "vidnotes"
		})
		.wikipedia({
			start: 40,
			end: 59,
			src: "http://en.wikipedia.org/wiki/Online_newspaper",
			title: "Online Newspapers",
			target: "vidnotes"
		})
		.wikipedia({
			start: 60,
			end: 79,
			src: "http://en.wikipedia.org/wiki/Tablet_computer",
			title: "Tablet Computers",
			target: "vidnotes"
		})
		.wikipedia({
			start: 80,
			end: 89,
			src: "http://en.wikipedia.org/wiki/Ereader",
			title: "e-readers",
			target: "vidnotes"
		})
		.wikipedia({
			start: 90,
			end: 114,
			src: "http://en.wikipedia.org/wiki/Flexible_LCD",
			title: "Flexible-LCD",
			target: "vidnotes"
		})
		.wikipedia({
			start: 115,
			end: 131,
			src: "http://en.wikipedia.org/wiki/E-book",
			title: "e-Books",
			target: "vidnotes"
		})
		.wikipedia({
			start: 132,
			end: 200,
			src: "http://en.wikipedia.org/wiki/Blog",
			title: "Blogs",
			target: "vidnotes"
		})
		.wikipedia({
			start: 174,
			end: 179,
			src: "http://en.wikipedia.org/wiki/Video_podcast",
			title: "Video Podcasts",
			target: "vidnotes"
		})
		.wikipedia({
			start: 180,
			end: 200,
			src: "http://en.wikipedia.org/wiki/Audio_podcast",
			title: "Audio Podcasts",
			target: "vidnotes"
		})
		.wikipedia({
			start: 220,
			end: 248,
			src: "http://en.wikipedia.org/wiki/Internet_research",
			title: "Internet Research Accuracy",
			target: "vidnotes"
		})
		.wikipedia({
			start: 249,
			end: 269,
			src: "http://en.wikipedia.org/wiki/Rats",
			title: "Rats",
			target: "vidnotes"
		})
		.wikipedia({
			start: 270,
			end: 278,
			src: "http://en.wikipedia.org/wiki/IPod",
			title: "iPod",
			target: "vidnotes"
		})
		.wikipedia({
			start: 279,
			end: 287,
			src: "http://en.wikipedia.org/wiki/Laptop",
			title: "Personal Computer",
			target: "vidnotes"
		})
		.footnote({
			start: 288,
			end: 303,
			text:"Thanks for watching the New Wrinkle video podcast",
			target: "vidnotes"
		});

});

//http://popcornjs.org/popcorn-docs/