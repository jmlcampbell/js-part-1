Add CSS to set hide image captions out of sight and create javascript functions so that on mouse hover the caption will slide up over the image, and on mouse out the caption will hide again 
-edit:
css/style.css line: 345
js/captionFX.js

Bonus: Add fancybox plugin to lightbox photos when you click on them.

Directions: http://fancybox.net/