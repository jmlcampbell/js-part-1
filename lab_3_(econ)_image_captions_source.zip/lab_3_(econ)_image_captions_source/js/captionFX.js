$(document).ready(function(){
	
	//start

});