Add user comment area to the designated section at the bottom of the page. Use an object to store the name, email, current date, and comment for the most recent input. Validate user fields and then print the comment above. 
-edit:
js/comments.js