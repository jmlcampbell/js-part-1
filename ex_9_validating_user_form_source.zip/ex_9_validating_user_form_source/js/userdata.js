$(document).ready(function(){

	//CREATE OBJECT (using Literal Notation)
	
		
	//DOM SEL VARS
	
	
	//INITIALLY HIDE ERRORS	


	//DISPLAY LIST FUNCTION
	
	
	//ADD_USER FORM SUBMIT EVENT FUNCTION
	
	///^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/
	
	//CLEAR BUTTON FUNCTION
	
		
});