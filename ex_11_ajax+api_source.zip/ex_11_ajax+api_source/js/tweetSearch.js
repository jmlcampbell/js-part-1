$(document).ready(function(){

	

});

/* RESOURCES

Twitter API: https://dev.twitter.com/

jQuery AJAX reference: http://api.jquery.com/category/ajax/

*/