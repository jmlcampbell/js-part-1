$(document).ready(function () {

	var vid1 = Popcorn('#vid1');
	var vid2 = Popcorn('#vid2');
	
	function padLeft(nr, n, str){
    	return Array(n-String(nr).length+1).join(str||'0')+nr;
	}
	
	//VIDEO 1
	vid1
		.footnote({
    		start: 1,
        	end: 4,
        	text: 'Hello there!',
        	target: 'text1'
    	})
    	.footnote({
    		start: 6,
        	end: 10,
        	text: 'Bet you like these swirling colors...?',
        	target: 'text1'
    	})
    	.footnote({
    		start: 12,
        	end: 16,
        	text: 'Careful, don\'t stare too long.',
        	target: 'text1'
    	})
    	.footnote({
    		start: 18,
    		end: 19,
    		text: '',
    		target: 'text1',
    		effect: 'applyclass',
    		applyclass: 'smirkyface'
    	})
		.autoplay(false)
	    .loop(false)
	    .controls(false)
	    .on('timeupdate', function(){
	    	$('#time1').html('Ellapsed: '+padLeft(parseInt(this.currentTime() / 60),2)+':'+padLeft(parseInt(this.currentTime()),2)+' Remaining: '+padLeft(parseInt((this.duration() - this.currentTime()) / 60),2)+':'+padLeft(parseInt(this.duration() - this.currentTime()),2));	
		});
    
    $('#play1').click(function(){
    	vid1.play();
    });
    
    $('#pause1').click(function(){
    	vid1.pause();
    });
    
    //VIDEO 2
	vid2
		.flickr({
        	start: 1,
        	end: 19,
        	tags: 'rainbow',
        	numberofimages: 9,
        	target: 'text2'
      	})
		.autoplay(false)
	    .loop(false)
	    .controls(false)
	    .on('timeupdate', function(){
	    	$('#time2').html('Ellapsed: '+padLeft(parseInt(this.currentTime() / 60),2)+':'+padLeft(parseInt(this.currentTime()),2)+' Remaining: '+padLeft(parseInt((this.duration() - this.currentTime()) / 60),2)+':'+padLeft(parseInt(this.duration() - this.currentTime()),2));	
		});
    
    $('#play2').click(function(){
    	vid2.play();
    });
    
    $('#pause2').click(function(){
    	vid2.pause();
    });



});