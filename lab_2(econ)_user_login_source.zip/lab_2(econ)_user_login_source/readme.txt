Set the login button to toggle the login form to show and hide when the user clicks on it. Also set the login form to be initially hidden, as well as the logout button, the 'Your subscriptions' link in the nav as well as the #subscriptions div. After the user logs in hide the form, hide the login button, and show the logout button, also show the 'Your Subscriptions' link in the nave bar and show the #subscriptions div
-edit: js/userstate.js

Bonus: ask instructor to demonstrate: navFX.js, scrollFX.js, and subscriptionFX.js from the completed code and try to add these features.